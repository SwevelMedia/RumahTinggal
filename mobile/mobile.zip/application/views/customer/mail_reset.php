


<!DOCTYPE html>
                        <head>
                            <title></title>
                            <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                            <meta name="viewport" content="width=device-width, initial-scale=1">
                            <meta http-equiv="X-UA-Compatible" content="IE=edge" />
                            <style type="text/css">
                               
                            </style>
                        </head>

                        <body style="background-color: #f4f4f4; margin: 0 !important; padding: 0 !important;">
                           <center><img src="https://rumahtinggal.id/assets/img/logo.png" style="padding-bottom: 15px;" width="90px">
                                Hai <h2>windahutari</h2>,
                                <br>
                                Kami telah menerima pengajuanmu untuk mengatur ulang kata sandi kamu.
                                <br>
                                Atur kembali kata sandi kamu di sini atau tempel tautan di bawah ini di
                                browser kamu.
                                <br>
                                <!-- https://rumahtinggal.id/forgot_password/?code=KWNwdi3fwv/cv4%2BDBCv%2BCHKwOWkijfhAL4Zl%2B9adQ7lGoSb2iS81fFm8lEW29uvw&email=windahutari30%40gmail.com -->
                                <a href="<?= base_url('reset_password') ?>"><?= base_url('reset_password') ?></a>
                                <hr>

                                LANGKAH SELANJUTNYA
                                <br>
                                Kamu akan menerima email konfirmasi untuk kata sandi barumu.
                                <br>
                                Jika kamu tidak meminta pengaturan ulang kata sandi, abaikan email ini.
                                <br>
                                Salam,
                                Tim rumahtinggal.id
                            </center>
                        </body>

                        </html>