<script src="<?= base_url('assets/vendor/bootstrap/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/js/easing.min.js') ?>"></script>			
<script src="<?= base_url('assets/js/hoverIntent.js') ?>"></script>
<script src="<?= base_url('assets/js/superfish.min.js') ?>"></script>	
<script src="<?= base_url('assets/js/jquery.ajaxchimp.min.js') ?>"></script>
<script src="<?= base_url('assets/js/jquery.magnific-popup.min.js') ?>"></script>	
<script src="<?= base_url('assets/js/jquery.sticky.js') ?>"></script>
<script src="<?= base_url('assets/js/jquery.nice-select.min.js') ?>"></script>			
<script src="<?= base_url('assets/js/parallax.min.js') ?>"></script>	
<script src="<?= base_url('assets/js/jquery.counterup.min.js') ?>"></script>
<script src="<?= base_url('assets/js/mail-script.js') ?>"></script>
<script src="<?= base_url('assets/vendor/jquery-rooster/rooster/jquery.rooster.js') ?>"></script>
<script src="<?= base_url('assets/vendor/ion-rangeslider/ion.rangeSlider.min.js') ?>"></script>
<!-- <script src="<?= base_url('assets/js/waypoints.min.js') ?>"></script> -->

<script src="<?= base_url('assets/vendor/slick/slick.min.js') ?>"></script>
<script src="<?= base_url('assets/js/icheck.min.js') ?>"></script>
<script src="<?= base_url('assets/js/jquery.email-autocomplete.min.js') ?>"></script>
<script src="<?= base_url('assets/js/modernizr-2.8.3-respond-1.4.2.min.js') ?>"></script>
<!-- Toastr -->
<script src="<?= base_url('assets/vendor/toastr/build/toastr.min.js') ?>"></script>
<!-- Star Rating -->
<script src="<?= base_url('assets/vendor/star-rating/jquery.starrating.min.js') ?>"></script>
<!-- Gallery Zoom -->
<script src="<?= base_url('assets/vendor/gallery-zoom/dist/zoomy.js') ?>"></script>
<!-- Ajax Loader -->
<script src="<?= base_url('assets/vendor/ajax-loader/jquery.loading.min.js') ?>"></script>
<script src="<?= base_url('assets/js/jquery.collapse.min.js') ?>"></script>
<script src="<?= base_url('assets/js/bootsnav.min.js') ?>"></script>
<script src="<?= base_url('assets/js/js.cookie.min.js') ?>"></script>
<script src="<?= base_url('assets/js/ticker-slide.min.js') ?>"></script>
<script src="<?= base_url('assets/js/js-rapstar.js') ?>"></script>
<!--<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBhOdIF3Y9382fqJYt5I_sswSrEw5eihAA"></script>-->
<script src="https://estimator.id/assets/js/js.cookie.min.js"></script>
<script src="https://apis.google.com/js/platform.js" async defer></script>
 <script src="https://apis.google.com/js/platform.js?onload=renderButton" async defer></script>
