<style>
.i-con-footer {
    font-size: 25px !important;
    color: #026CB6;
    margin: 0px 7px 23px 0px;
}
  
.line-footer {
    width: 70px;
    height: 3px;
    background: #026CB6;
    margin-bottom: 13px;
    margin-top: 3px;
}
  
.menu-footer { width: 10em; }  
  
.menu-footer a { color: #000; }
  
.menu-footer a:hover { color: #026CB6; }

.footer-area {
	background-color: #fff !important;
  	color: #000;
  	border-top: 1px solid #f7f7f7;
  	font-weight: 300;
  	font-size: 15px;
  	padding: 20px 0 0;
  	height: 188px;
}

.footer-area h4 {
  	padding-bottom: 1px !important;
  	font-size: 16px;
    font-weight: 400;
  	color: #000;
}

@media only screen and (max-width:768px) {
	/* For tablets: */
	.i-con-footer {
	    font-size: 25px !important;
	    color: #026CB6;
	    margin: 0px 7px 23px 0px;
	}
	  
	.line-footer {
	    width: 70px;
	    height: 3px;
	    background: #026CB6;
	    margin-bottom: 13px;
	    margin-top: 3px;
	}
	  
	.menu-footer { width: 10em; }  
	  
	.menu-footer a { color: #000; }
	  
	.menu-footer a:hover { color: #026CB6; }

	.footer-area {
	  	height: auto;
	}

	.mo-footer {
    width: auto;
    padding: 0;
	}

	.footer-area h4 {
	  	padding-bottom: 1px !important;
	  	font-size: 16px;
	    font-weight: 400;
	  	color: #000;
	}
}
</style>

<footer class="footer-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-6 col-md-6 col-sm-6 p0 mo-footer">
				<div class="single-footer-widget">
					<h4>Tentang Kami</h4>
					<div class="line-footer"></div>
					<p style="width: 103%;">
						RumahTinggal.id merupakan marketplace desain rumah untuk mewujudkan hunian idaman Anda<br>Dapatkan desain hunian terbaik dengan mudah, hemat, dan berkualitas 
					</p>
					<p style="margin-bottom: 0">
                         <a href="https://www.facebook.com/rumahtinggal.id/" target="_blank"><i class="fa fa-facebook i-con-footer" aria-hidden="true"></i></a>	
                         <a href="https://www.instagram.com/rumahtinggal_id/" target="_blank"><i class="fa fa-instagram i-con-footer" aria-hidden="true"></i></a>
                         <a href="https://twitter.com/rumahtinggal_id" target="_blank"><i class="fa fa-twitter i-con-footer" aria-hidden="true"></i></a>
                         <a href="https://api.whatsapp.com/send?phone=628112636228&text=Hai%20rumahtinggal.id%2C%20saya%20ingin%20bertanya%20mengenai%20desain%20rumahtinggal.id%20" target="_blank"><i class="fa fa-whatsapp i-con-footer" aria-hidden="true"></i></a> 	
                     
                      <a href="https://id.pinterest.com/rumahtinggalid" target="_blank"><i class="fa fa-pinterest i-con-footer" aria-hidden="true"></i></a> 
                         <a href=" https://mail.google.com/mail/?view=cm&fs=1&to=mail.rumahtinggal@gmail.com&su=Tanya rumahtinggal.id&body=Hai rumahtinggal.id, saya ingin bertanya mengenai desain di rumahtinggal.id" target="_blank"><i class="fa fa-envelope i-con-footer" aria-hidden="true"></i></a>
                  	</p>
                 
				</div>
			</div>
			<div class="col-lg-6  col-md-6 col-sm-6 p0 mo-footer" >
				<div class="single-footer-widget" style="float: right;">
					<h4>Layanan Pengguna</h4>
					<div class="line-footer"></div>
					<div class="menu-footer"><a href="<?= base_url('kebijakan_privasi') ?>">Kebijakan Privasi</a></div>
					<div class="menu-footer"><a href="<?= base_url('syarat_ketentuan') ?>">Syarat dan Ketentuan</a></div>
					<div class="menu-footer"><a href="<?= base_url('cara_kerja') ?>">Cara Kerja</a></div>
					<div class="menu-footer"><a href="<?= base_url('faq') ?>">FAQ</a></div>
					<div class="menu-footer"><a href="<?= base_url('sampel_desain') ?>">Sampel Desain</a></div>
				</div>
          	</div>
		</div>
		
	</div>
</footer>	
<div class="row" style="margin-right: 0;">
	<div class="col-md-12 text-center" style="background: #026CB6;color: #fff;font-size: 15px;line-height: 40px;height: 40px;">
		<span>RumahTinggal.id © 2020. All right reserved.</span>
	</div>
</div>