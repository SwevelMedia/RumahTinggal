<style>
#header {
    background: #fff;
    padding: 8px 0;
    box-shadow: 0 0.1px 3px rgba(0, 0, 0, 0.1);
}
  
#header.header-scrolled {
    background: rgba(255, 255, 255, 0.9);
    transition: all 0.5s;
}
  
.nav-menu a {
    padding: 2px 10px;
    display: inline-block;
    font-weight: 300;
    font-size: 15px;
    outline: none;
  	text-decoration: none !important;
}
  
.nav-menu > li { margin-left: 5px; }  
  
.nav-menu .dropbtn {
    background: #fff;
    color: #000;
    padding: 6px;
    font-size: 15px;
    border: none;
    cursor: pointer;
    font-weight: 300;
}
  
.nav-menu .dropbtn::after {
    font-family: FontAwesome;
    content: "\f107";
    font-size: 14px;
    padding-left: 7px;
}  

.nav-menu .dropdown {
    position: relative;
    display: inline-block;
}
  
.nav-menu .dropdown span {  
	font-weight: 400; 
  	color: #026cb6;
}

.nav-menu .dropdown-content {
    display: none;
    position: absolute;
  	padding: 5px 0;
    background: #fff;
    width: 180px;
	right: 0;
    box-shadow: 0 14px 8px -10px rgba(0,0,0,0.2);
    z-index: 1;
}
  
.nav-menu .dropdown:hover .dropdown-content { display: block; }  

.nav-menu .dropdown-content a {
    color: #000;
    padding: 3px 10px;
    display: block;
    text-transform: none;
}
  
.nav-menu .dropdown-content a:hover { color: #026cb6; }
  
.nav-menu .dropdown-content i {
  	margin-right: 4px;
	color: #026cb6;
  	font-size: 13px;
}
  
.nav-menu #menu-login a {
    padding: 6px 12px;
    font-size: 12px;
    font-weight: 400;
    color: #fff;
}
</style>

<header id="header" id="home">
    <div class="container">
        <div class="row align-items-center justify-content-between d-flex">
          <div id="logo">
            <a href="<?= base_url() ?>"><img src="<?= base_url('assets/img/logo.png') ?>" width="70px"/></a>
          </div>
          <nav id="nav-menu-container" style="padding-right: 0;">
            <ul class="nav-menu">
              <li class="menu-has-children" id="menu-login" style="display: none;"><a href="javascript:void(0)" data-toggle="modal" data-target="#ModalLogin" class="btn btn-custom login">Masuk</a></li>
              <li class="dropdown" id="menu-pengguna" style="display: none;margin-top: -2px;">
                  <button class="dropbtn">Halo, <span id="nama_customer"></span></button>
                  <div class="dropdown-content">
                   <a href="javascript:void(0)" onclick="profil()"><i class="fa fa-user" style="font-size: 15px;margin-left: 2px;margin-right: 5px;"></i>Profil</a>
                    <a href="javascript:void(0)" onclick="daftarFavorit()"><i class="fa fa-heart"></i> Daftar Favorit</a>
                     <a href="javascript:void(0)" onclick="transaksiPembelian()"><i class="fa fa-shopping-bag"></i> Transaksi Pembelian</a>
                    <a href="javascript:void(0)" onclick="logout()"><i class="fa fa-sign-out" style="font-size: 15px;margin-left: 1px;margin-right: 2px;"></i> Keluar</a>
                  </div>
              </li>
              <!-- <li class="menu-has-children"><a href="javascript:void(0)"><i class="fa fa-bell" style="color: #ffbf00;font-size: 20px;margin-top: 3px;"></i></a></li> -->
            </ul>
          </nav>		    		
        </div>
    </div>
</header>

<script>
	$(document).ready(function() {
      	let id_customer = Cookies.get('id_customer', { domain: 'rumahtinggal.id' });
      	if (id_customer != null && id_customer != '') {
          	$('#menu-login').hide();
          	$('#menu-pengguna').show();
          	$.ajax({
               url: "<?= base_url('api/getCustomerById/') ?>"+id_customer,
               type: "GET",
               dataType: "JSON",
               success: function(data){
                  $('#nama_customer').html(data.nama_customer+'!');
               }
            });
          
          	$.ajax({
               url: "<?= base_url('api/getRumahSuka/') ?>"+id_customer,
               type: "GET",
               dataType: "JSON",
               success: function(data){
                  if (data != ''){
                      $.each(data, function(i, item) {
                          let id_rumah = item.id_rumah;
                          $('.like .fa[data-id="'+id_rumah+'"]').removeClass('fa-heart-o').addClass('fa-heart').css('color','red');
                      });
                  }
               }
            });
        } else {
          	$('#menu-login').show();
          	$('#menu-pengguna').hide();
        }
      
      	$('#login-no_wa,#daftar-no_wa,#otp_verifikasi,#otp_aktivasi').keypress(function (e) {
            let keyCode = e.keyCode || e.which;
            let regex = /^[0-9 ()+-]+$/;
            let isValid = regex.test(String.fromCharCode(keyCode));
            return isValid;
        });
      
      	$('.like .fa').on('click', function(){
          	if (id_customer != null && id_customer != '') {
              let id_rumah = $(this).data('id');
              let jum_stat = $(this).next().text();
              if ($(this).hasClass('fa-heart-o')) {
                  $(this).removeClass('fa-heart-o').addClass('fa-heart').css('color','red');
                  jum_stat++;
                  
                  $.ajax({
                     url: "<?= base_url('api/simpanDisukai') ?>",
                     type: "POST",
                     data: {"id_rumah": id_rumah,"id_customer": id_customer,"suka": 1},
                     dataType: "JSON",
                     success: function(data){}
                  });
              } else {
                  $(this).removeClass('fa-heart').addClass('fa-heart-o').css('color','#026cb6');
                  jum_stat--;
                
                  $.ajax({
                     url: "<?= base_url('api/hapusDisukai/') ?>"+id_rumah+"/"+id_customer,
                     type: "POST",
                     dataType: "JSON",
                     success: function(data){}
                  });
              }
              $(this).next().text(jum_stat);
            } else $('#ModalLogin').modal('show');
        });
      
      	$('.btn-beli-desain').on('click', function(e){
            if (id_customer == null || id_customer == '') {
              e.preventDefault();
              $('#ModalLogin').modal('show');
              return false;
            }
        });
      
      	$('.btn-tulis-ulasan').on('click', function(e){
            if (id_customer == null || id_customer == '') {
              e.preventDefault();
              $('#ModalLogin').modal('show');
              return false;
            }
        });
      
      	if (isMobile() == true){
            $('.product-grid .image, .product-grid .title').prop('onclick','').on('click', function(e){
            	$(this).trigger('hover');
            });
        }
    });
  
  	function detailRumah(id){
        location.href = "<?= base_url('detail/') ?>"+id;
    }
  
  	function detailArsitek(id){
        location.href = "<?= base_url('profil_arsitek/') ?>"+id;
    }
  
  	function temukanDesain(){
      	location.href = "<?= base_url('assessment') ?>";
    }
  
    function profil(){
        let id_customer = Cookies.get('id_customer', { domain: 'rumahtinggal.id' });
        location.href = "<?= base_url('profil/') ?>"+id_customer;
    }

    function daftarFavorit(){
        let id_customer = Cookies.get('id_customer', { domain: 'rumahtinggal.id' });

        location.href = "<?= base_url('profil/') ?>"+id_customer+"#favorit";

    }

     function transaksiPembelian(){
        let id_customer = Cookies.get('id_customer', { domain: 'rumahtinggal.id' });

        location.href = "<?= base_url('profil/') ?>"+id_customer+"#transaksi";

    }

  	function number_format(number, decimals, dec_point, thousands_point) {
        if (number == null || !isFinite(number)) { throw new TypeError("number is not valid"); }
        if (!decimals) {
            let len = number.toString().split('.').length;
            decimals = len > 1 ? len : 0;
        }
        if (!dec_point) { dec_point = '.'; }
        if (!thousands_point) { thousands_point = ','; }
      
        number = parseFloat(number).toFixed(decimals);
        number = number.replace(".", dec_point);
        var splitNum = number.split(dec_point);
        splitNum[0] = splitNum[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousands_point);
        //number = splitNum.join(dec_point);
      	number = splitNum[0];
    
        return number;
    }
  
  	function isMobile() {
      var check = false;
      (function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) check = true;})(navigator.userAgent||navigator.vendor||window.opera);
      return check;
    };

//     function getMobileOperatingSystem() {
//   var userAgent = navigator.userAgent || navigator.vendor || window.opera;

//   if( userAgent.match( /iPad/i ) || userAgent.match( /iPhone/i ) || userAgent.match( /iPod/i ) )
//   {
//     return 'true';

//   }
//   else if( userAgent.match( /Android/i ) )
//   {

//     return 'true';
//   }
//   else
//   {
//     return 'unknow';
//   }
// }
  

        // var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        // var element = document.getElementById('text');
        // if (isMobile) {
        //     element.innerHTML = "You are using Mobile";
        // } else {
        //     element.innerHTML = "You are using Desktop";
        // }
/**
 * jQuery.browser.mobile (http://detectmobilebrowser.com/)
 * jQuery.browser.mobile will be true if the browser is a mobile device
 **/
(function(a){(jQuery.browser=jQuery.browser||{}).mobile=/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))})(navigator.userAgent||navigator.vendor||window.opera);


  	function konsultasiDesain(){
      	var text = `Halo,\nSaya ingin mengkonsultasikan desain rumah saya.\nApakah bisa dibantu?\nTerima kasih`;
        var phone = '628112636228';
        var message = encodeURIComponent(text);

        // if (getMobileOperatingSystem() == true){
        //     var whatsapp_API_url = "https://api.whatsapp.com/send";
        //     $(this).attr( 'href', whatsapp_API_url+'?phone=' + phone + '&text=' + message );
        // } else {
        //     var whatsapp_API_url = "https://web.whatsapp.com/send";
        //     var url = whatsapp_API_url+'?phone=' + phone + '&text=' + message; 
        //     window.open(url, '_blank');
        // }

if(jQuery.browser.mobile)
{
    console.log('You are using a mobile device!');
    var whatsapp_API_url = "https://api.whatsapp.com/send";
    // $(this).attr( 'href', whatsapp_API_url+'?phone=' + phone + '&text=' + message );
     var url = 'https://api.whatsapp.com/send?phone=' + phone + '&text=' + message;

  // return url
   window.open(url);
}
else
{
   console.log('You are not using a mobile device!');
   var whatsapp_API_url = "https://api.whatsapp.com/send";
    var url = whatsapp_API_url+'?phone=' + phone + '&text=' + message; 
    window.open(url, '_blank');
}


        // var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        // // var element = document.getElementById('text');
        // if (isMobile) {
        //     var whatsapp_API_url = "whatsapp://send";
        //     $(this).attr( 'href', whatsapp_API_url+'?phone=' + phone + '&text=' + message );
        // } else {
        //     var whatsapp_API_url = "https://web.whatsapp.com/send";
        //     var url = whatsapp_API_url+'?phone=' + phone + '&text=' + message; 
        //     window.open(url, '_blank');
        // }
    }
    
    function logout() {
    //      var auth2 = gapi.auth2.getAuthInstance();
    // auth2.signOut().then(function () {
    //   console.log('User signed out.');
    // });

      	window.location.href = "<?= base_url('logout') ?>";
// $.ajax({
//          url: "<?= base_url('logout') ?>",
//          type: "POST",
//          // data: {"id_rumah": id_rumah,"id_customer": id_customer,"suka": suka},
//          dataType: "JSON",
//          success: function(data){
//              var auth2 = gapi.auth2.getAuthInstance();
//     auth2.signOut().then(function () {
//       console.log('User signed out.');
       
//       // window.location.href = "<?= base_url('logout') ?>";
//     });
//          }
//       });
    }
  
  	/*function like(index){
      var id_customer=1;
      var id_rumah=index;
      var suka=1;

      var jumlikeplus = Number($('#jumlike'+index).html())+Number(1);

      $.ajax({
         url: "<?= $this->config->item('url_arsi') ?>api/simpanDisukai",
         type: "POST",
         data: {"id_rumah": id_rumah,"id_customer": id_customer,"suka": suka},
         dataType: "JSON",
         success: function(data){}
      });
      
      $.ajax({
         url: "<?= $this->config->item('url_arsi') ?>api/rumahSuka/"+index,
         type: "POST",
         dataType: "JSON",
         success: function(data){
           	$("#jumlike"+index).html(jumlikeplus);
            $("#like"+index).removeClass('like').addClass('unlike').prop('id', 'unlike'+index).attr('onclick', 'unlike('+index+')');
            $("#like"+index+" .i-heart").addClass('red');
         }
      });
    }
  
    function unlike(index){
      var id_customer=1;
      var id_rumah=index;
      var suka=1;

      var jumlikemin = Number($('#jumlike'+index).html())-Number(1);

      $.ajax({
         url: "<?= $this->config->item('url_arsi') ?>api/hapusDisukai/"+index+"/"+id_customer,
         type: "POST",
         dataType: "JSON",
         success: function(data){}
      });
      
      $.ajax({
         url: "<?= $this->config->item('url_arsi') ?>api/rumahBatalSuka/"+index,
         type: "POST",
         dataType: "JSON",
         success: function(data){
           	$("#jumlike"+index).html(jumlikemin);
            $("#unlike"+index).removeClass('unlike').addClass('like').prop('id', 'like'+index).attr('onclick', 'like('+index+')');
            $("#unlike"+index+" .i-heart").removeClass('red');
         }
      });
  	}*/
</script>

<?php $this->load->view('beranda/login') ?>