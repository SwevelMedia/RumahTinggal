<style>

@media only screen and (max-width: 360px) {
    #nav-menu-container {
        display: initial !important;
        padding-right: 90px !important;
    }
    .pop-up-website{
        width: 300px !important;
    }
    .modal-dialog.animated.tada {
        width: auto !important;
    }
    .btn-pop-up{
        margin-top: -120px !important;
        font-size: 15px !important;
    }
    #pop_up_website{
        padding-right: 83px !important;
    }
    #pop_up_website .close {
        top: 23px !important;
        right: 36px !important;
    }
    .artikel-mobile{
        padding: 0 5px !important;
    }
    .artikel-mobile img{
        height: 55%;
    }
    .artikel-mobile .product-grid .product-image {
        height: 108px !important;
    }
    .artikel-mobile .product-grid{
        height: 260px !important;
    }
    .artikel-mobile .publish{
        font-size: 10px !important;
    }
    .artikel-mobile .title{
        font-size: 10px !important;
    }
    .artikel-mobile .product-content .publish::before{
        font-size: 10px !important;
    }
    .artikel-mobile .product-content .title{
        height: 28px !important;
        font-size: 10px !important;
    }
    .artikel-mobile .product-content .content {
        height: 59px !important;
    }
    .artikel-mobile .product-content .content p{
        font-size: 11px !important;
    }
    .artikel-mobile .product-content .link {
        font-size: 12px !important;
    }
    .artikel-mobile .product-content .link::after {
        font-size: 12px !important;
    }
}











#pop_up_website .modal-dialog {
    max-width: 640px;
    margin: 130px auto;
}
#pop_up_website .close {
    color: #fff;
}
.slide-brand {
    width: 165px;
    height: 95px;
    border-radius: 10px;
    cursor: pointer;
  	margin: 0 7px;
}
  
.banner-slider {
    background-size: 100% 100%;
    background-repeat: no-repeat;
    height: 340px;
}  

.product-slider {
  	left: 18.5%;
	max-width: 80%;
  	margin-top: 16px;
}
  
@media only screen and (min-width: 1440px) {
    .list-produk-promo .grid, .list-produk-favorit .grid { width: 255px !important; }
  	
    .list-produk-popular .grid { width: 255.2px !important; }
  
    .list-produk .grid { width: 245px !important; }
  
  	.list-artikel .grid { width: 375px !important; }
  
  	.product-grid .suplier { width: 70% !important; }
  
  	#btn-lihat-koleksi { left: 64.5% !important; }
  
  	.slide-brand { width: 175px !important; }
  
  	.sec-category { max-width: 17% !important; }
  
  	.sec-product {
      	max-width: 83% !important;
      	flex: 0 0 83% !important;
    }
}  
  
.list-produk-promo .grid, .list-produk-favorit .grid { height: 395px; }

.list-produk-popular .grid {
    width: 19.75%;
  	height: 320px;
    display: inline-flex;
}
  
.list-produk-popular .product-grid {
    margin: 0;
    padding: 4px;
}
  
.product-grid .jstars {
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
}  
  
.katalog-produk .form-control:focus { box-shadow: none; }

.katalog-produk .form-control::placeholder {
  	font-size: 0.95rem;
  	color: #aaa;
}
   
.katalog-produk .result {
  	background: #fff;
  	padding: 15px;
}
  
.list-category {
  	background: #fff;
	border: 1px solid rgba(0, 0, 0, 0.1);
}
  
.list-category.merk { margin-top: 15px; }

.list-category .header { 
  	padding: 11px 14px;
	background: #026CB6;
}

.list-category h5 {
  	color: #fff;
  	font-weight: 400;
  	font-size: 15px;
}

.list-category h5::before {
  	font-family: FontAwesome;
	content: "\f00b";
	padding-right: 9px;
	font-size: 14px;
}
  
.list-category.merk h5::before { content: "\f02c"; }

.list-category .icon {
  	position: relative;
	height: 22px;
	width: 22px;
	margin-right: 10px;
	margin-top: -3px;
}

.list-category .body li {
	font-size: 15px;
	padding: 7px 12px;
  	color: #000;
}

.list-category.merk .list-group {
  	padding: 7px 0;
}
  
.list-category.merk .list-group-item {
    border: none;
    padding: 3px 12px;
}

.list-category .body li:not(:last-child) { border-bottom: 1px solid rgba(0, 0, 0, 0.1); }

.list-category .body li:hover {
  	color: #fff;
	background: #026cb6;
	cursor: pointer;
  	-webkit-transition-property: background;
    -webkit-transition-duration: 0.2s;
    -webkit-transition-timing-function: ease-out;
    transition-property: background;
    transition-duration: 0.2s;
    transition-timing-function: ease-out;
}

.list-category .body li .badge {
    width: 37px;
    padding: 4px;
}

.list-category .body li:hover .badge {
  	color: #026cb6;
	background: #fff;
}
  
@keyframes check {
  	0% { height: 0;width: 0; }
    25% { height: 0;width: 8px; }
    50% { height: 20px;width: 8px; }
}
  
.checkbox {
  	background: #fff;
    height: 23px;
    width: 23px;
    border: 1px solid rgba(0, 0, 0, 0.1);
  	cursor: pointer;
  	margin-bottom: 0;
}
  
.checkbox span {
  	display: block;
  	position: relative;
  	height: 23px;
  	width: 23px;
  	padding: 0;
}
 
.checkbox span .item {
  	margin-left: 31px;
	color: #000;
  	width: 210%;
  	display: table-caption;
}
  
.checkbox span:after {
  	-moz-transform: scaleX(-1) rotate(135deg);
  	-ms-transform: scaleX(-1) rotate(135deg);
  	-webkit-transform: scaleX(-1) rotate(135deg);
  	transform: scaleX(-1) rotate(135deg);
  	-moz-transform-origin: left top;
  	-ms-transform-origin: left top;
  	-webkit-transform-origin: left top;
  	transform-origin: left top;
  	border-right: 3px solid #fff;
    border-top: 3px solid #fff;
    content: '';
    display: block;
    height: 16px;
    position: absolute;
    top: 12px;
    width: 8px;
    left: 2px;
}
  
.checkbox input { display: none; }
  
.checkbox input:checked + span:after {
  	-webkit-animation: check .8s;
  	-moz-animation: check .8s;
  	-o-animation: check .8s;
  	animation: check .8s;
}
  
.checkbox input:checked + .primary:after { border-color: #026CB6; }
  
.checklist .badge {
    width: 37px;
    padding: 4px;
}

.dropdown-menu.show {
    display: block;
    padding: 2px 0;
    border-radius: 0;
    color: #000;
    font-size: 14px;
    min-width: 123px;
}
  
.dropdown-menu li {
    padding: 1px 11px;
  	cursor: pointer;
}
  
.dropdown-menu li:hover {
    background: #026CB6;
  	color: #fff;
}
  
.testimonial { text-align: center; }
  
.testimonial .description {
    color: #000;
    font-size: 20px;
    line-height: 1.3;
    margin-bottom: 20px;
    padding: 0 60px;
}
  
.testimonial .description::before {
    content: "\f10d";
    font-family: "FontAwesome";
    font-weight: 500;
    display: inline-block;
    position: absolute;
    top: 0;
    left: 20px;
    color: #026cb6;
    font-size: 30px;
}
  
.testimonial .description::after {
    content: "\f10e";
    font-family: "FontAwesome";
    font-weight: 500;
    display: inline-block;
    position: absolute;
    top: 0;
    right: 20px;
    color: #026cb6;
    font-size: 30px;
}
  
.testimonial .review .pic {
    width: 94px;
    height: 94px;
    margin: 0 auto;
}
  
.testimonial .review .pic img {
    width: 100%;
    height: auto;
    border-radius: 50%;
}
  
.testimonial .review .title {
    font-size: 18px;
    color: #026cb6;
    font-weight: 400;
    margin-top: 8px;
}
  
.testimonial .review .title small{
    display: block;
    font-size: 15px;
    font-weight: 300;
  	color: #000;
}

.flickity-page-dots .dot {
    display: inline-block;
    width: 10px;
    height: 10px;
    margin: 0 8px;
    background: #026CB6 !important;
    border-radius: 50%;
    filter: alpha(opacity=25);
    opacity: 0.25;
    cursor: pointer;
}

.gallery-cell {
    width: 66%;
    height: 300px;
    margin-right: 10px;
    background: transparent;
    counter-increment: gallery-cell;
    top: 15px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    border-radius: 20px;
}

.gallery-cell:before {
  	display: block;
  	text-align: center;
  	line-height: 200px;
  	font-size: 80px;
  	color: white;
}

.flickity-viewport {
    overflow: hidden;
    position: relative;
    height: 330px !important;
}

.flickity-prev-next-button .arrow { fill: #fff !important; }
  
.flickity-prev-next-button:hover { background: #026CB6 !important; }
  
.ribbon {
    position: absolute;
    z-index: 100;
}
  
.ribbon-promo {
    width: 93px;
    height: 24px;
    padding-left: 8px;
  	padding-top: 1px;
    position: absolute;
    left: -7px;
    top: 6px;
    background: #EE1212;
  	color: #fff;
    font-size: 14px;
  	box-shadow: 0 2px 2px rgba(0,0,0,.3);
}
  
.ribbon-promo:before, .ribbon-promo:after {
  	content: '';
  	position: absolute;
}
  
.ribbon-promo:before {
    top: -7px;
    left: -0.5px;
    border-bottom: 7px solid #4a0202;
    border-left: 8px solid transparent;
}
  
.ribbon-promo:after {
    right: -11px;
    border-top: 13px solid transparent;
    border-bottom: 0 solid transparent;
    border-left: 11px solid #4a0202;
}
</style>

<!-- <section class="offered-area section-gap" id="offered" style="margin-top: 2em;"> -->
    <div class="gallery js-flickity" id="gallery" data-flickity-options='{ "wrapAround": true,"autoPlay": 5000 }' style="margin-top: 55px;">
      	<div class="gallery-cell"><img src="<?= base_url('assets/img/beranda/slider_1.png') ?>" class="d-block w-100" style="height: 300px;" /></div>
      	<div class="gallery-cell"><img src="<?= base_url('assets/img/beranda/slider_2.jpg') ?>" class="d-block w-100" style="height: 300px;" /></div>
      	<div class="gallery-cell"><img src="<?= base_url('assets/img/beranda/slider_3.jpg') ?>" class="d-block w-100" style="height: 300px;" /></div>
    </div>
<!-- </section> -->

<section class="center" style="padding: 70px 0 40px 0;">
    <h1 style="font-weight: 400;">RumahTinggal.id adalah marketplace desain rumah idaman Anda</h1>
    <h3 style="font-weight: 300;">Dapatkan desain rumah tinggal terbaik dengan mudah, hemat, dan berkualitas</h3>
</section>
   
<section class="section-gap mb-20" id="offered">
    <div class="container p0">
        <div class="row">
            <div class="col-md-5" style="flex: 0 0 40%;padding-right: 3px;">
              	<button class="btn btn-banner danger" id="btn-temukan" onclick="temukanDesain()" style="left: 46.5%;bottom: 25px;">Temukan Desain</button>
              	<button class="btn btn-banner" id="btn-lihat-koleksi" onclick="lihatKoleksi()" style="left: 71.3%;bottom: 25px;">Lihat Koleksi</button>
                <img src="<?= base_url('assets/img/beranda/cari_desain.jpg') ?>" class="d-block w-100">     
            </div>
            <div class="col-md-2">
              	<button class="btn btn-banner" id="btn-lihat-sampel" style="left: 15%;bottom: 25px;" onclick="lihatSampel()">Lihat Sampel</button>
                <img src="<?= base_url('assets/img/beranda/sampel_desain.jpg') ?>" class="d-block w-100" style="height: 100%;"> 
            </div>
            <div class="col-md-5" style="flex: 0 0 40%;padding-left: 3px;">
              	<button class="btn btn-banner danger" id="btn-konsultasi" style="left: 44%;bottom: 25px;" onclick="konsultasiDesain()">Konsultasi Desain</button>
                <img src="<?= base_url('assets/img/beranda/konsultasi.jpg') ?>" class="d-block w-100"> 
            </div>
		</div>
  	</div>
</section>

<section class="pb-4">
  <div class="container">
     <div class="row banner-slider" style="background-image: url(<?= base_url('assets/img/banner/banner_promo_3.jpg') ?>);">
         <div class="col-md-9 product-slider">
              <div class="list-produk-promo">
              <?php
                  if ($produk_promo != '') {
                      foreach($produk_promo as $item) { ?>
                        <div class="col-md-3 p0 grid">
                            <div class="product-grid">
                              	<div class="ribbon"><span class="ribbon-promo"><?= 'Cut-Off '.$item->promo.'%' ?></span></div>
                              	<div class="product-image desain">
                                    <a href="javascript:void(0)" class="image" onclick="detailRumah(<?= $item->id_rumah ?>)">
                                        <img class="pic-1" src="<?= base_url('assets/img/desain/'.$item->foto) ?>">
                                        <img class="pic-2" src="<?= base_url('assets/img/desain/'.$item->foto) ?>">
                                    </a>
                                </div>
                                <div class="product-content">
                                    <div class="title" title="<?= $item->nama_rumah ?>" onclick="detailRumah(<?= $item->id_rumah ?>)"><?= $item->nama_rumah ?></div>
                                    <div class="product-rating">
                                        <div class="arsitek" title="<?= $item->nama_arsitek ?>" onclick="detailArsitek(<?= $item->id_arsitek ?>)"><?= $item->nama_arsitek ?></div>
                                        <div class="jstars" data-value="<?= $item->rating ?>" data-color="gold" data-size="17px"></div>
                                    </div>
                                    <div class="product-feature">
                                        <div class="feature" data-tootik="Luas Lahan" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_luas_lahan.png') ?>" />
                                            <span><?= $item->luas_lahan ?> m<sup>2</sup></span>
                                        </div>
                                        <div class="feature" data-tootik="Luas Bangunan" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_luas_bangunan.png') ?>" />
                                            <span><?= $item->luas_bangunan ?> m<sup>2</sup></span>
                                        </div>
                                        <div class="feature" data-tootik="Lantai" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_jml_lantai.png') ?>" />
                                            <span><?= $item->lantai ?></span>
                                        </div>
                                        <div class="feature" data-tootik="Kamar Tidur" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_kmr_tidur.png') ?>" />
                                            <span><?= $item->kamar_tidur ?></span>
                                        </div>
                                        <div class="feature" data-tootik="Toilet" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_toilet.png') ?>" />
                                            <span><?= $item->toilet ?></span>
                                        </div>
                                    </div>
                                    <div class="product-detail">
                                        <p class="lahan-minimal">Lahan minimal <span class="bold"><?= $item->lebar_lahan.' m x '.$item->panjang_lahan.' m' ?></span></p>
                                      	<p>Biaya konstruksi <span class="bold" data-tootik="Estimasi awal" data-tootik-conf="square"><?= $item->lantai == '1' ? "Rp".number_format(3500000 * $item->luas_bangunan, 0, ",", ".") : "Rp".number_format(4500000 * $item->luas_bangunan, 0, ",", ".") ?></span></p>
                                      	<div class="product-statistic">
                                            <div class="statistic">
                                                <button class="btn btn-detail" onclick="detailRumah(<?= $item->id_rumah ?>)">Detail</a>
                                            </div>
                                            <div class="statistic">
                                                <span class="view">
                                                  	<i class="fa fa-eye"></i><?= $item->dilihat ?>
                                              	</span>
                                            </div>
                                            <div class="statistic">
                                              	<span class="like">
                                                	<i class="fa fa-heart-o" data-id="<?= $item->id_rumah ?>"></i><span class="value"><?= $item->suka ?></span>
                                                </span>
                                            </div>
                                          	<div class="statistic">
                                                <div class="share"><i class="fa fa-share-alt"></i>
                                                  <div class="social">
                                                      <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                                                      <a class="twitter" href="https://twitter.com/intent/tweet?text=Hello%20twitter%20https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                                                      <a class="whatsapp" href="https://web.whatsapp.com/send?text=https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah.' '.$item->nama_rumah ?>" target="_blank"><i class="fa fa-whatsapp"></i></a>
                                                  </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
              <?php }} ?>
              </div>
          </div>
      </div>
  </div>
</section>

<section class="pb-4 mt-30">
  <div class="container">
     <div class="row banner-slider" style="background-image: url(<?= base_url('assets/img/banner/banner_favorit_3.jpg') ?>);">
         <div class="col-md-9 product-slider">
              <div class="list-produk-favorit">
              <?php
                  if ($produk_favorit != '') {
                      foreach($produk_favorit as $item) { ?>
                        <div class="col-md-3 p0 grid">
                            <div class="product-grid">
                                <div class="product-image desain">
                                    <a href="javascript:void(0)" class="image" onclick="detailRumah(<?= $item->id_rumah ?>)">
                                        <img class="pic-1" src="<?= base_url('assets/img/desain/'.$item->foto) ?>">
                                        <img class="pic-2" src="<?= base_url('assets/img/desain/'.$item->foto) ?>">
                                    </a>
                                </div>
                                <div class="product-content">
                                    <div class="title" title="<?= $item->nama_rumah ?>" onclick="detailRumah(<?= $item->id_rumah ?>)"><?= $item->nama_rumah ?></div>
                                    <div class="product-rating">
                                        <div class="arsitek" title="<?= $item->nama_arsitek ?>" onclick="detailArsitek(<?= $item->id_arsitek ?>)"><?= $item->nama_arsitek ?></div>
                                        <div class="jstars" data-value="<?= $item->rating ?>" data-color="gold" data-size="17px"></div>
                                    </div>
                                    <div class="product-feature">
                                        <div class="feature" data-tootik="Luas Lahan" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_luas_lahan.png') ?>" />
                                            <span><?= $item->luas_lahan ?> m<sup>2</sup></span>
                                        </div>
                                        <div class="feature" data-tootik="Luas Bangunan" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_luas_bangunan.png') ?>" />
                                            <span><?= $item->luas_bangunan ?> m<sup>2</sup></span>
                                        </div>
                                        <div class="feature" data-tootik="Lantai" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_jml_lantai.png') ?>" />
                                            <span><?= $item->lantai ?></span>
                                        </div>
                                        <div class="feature" data-tootik="Kamar Tidur" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_kmr_tidur.png') ?>" />
                                            <span><?= $item->kamar_tidur ?></span>
                                        </div>
                                        <div class="feature" data-tootik="Toilet" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_toilet.png') ?>" />
                                            <span><?= $item->toilet ?></span>
                                        </div>
                                    </div>
                                    <div class="product-detail">
                                        <p class="lahan-minimal">Lahan minimal <span class="bold"><?= $item->lebar_lahan.' m x '.$item->panjang_lahan.' m' ?></span></p>
                                      	<p>Biaya konstruksi <span class="bold" data-tootik="Estimasi awal" data-tootik-conf="square"><?= $item->lantai == '1' ? "Rp".number_format(3500000 * $item->luas_bangunan, 0, ",", ".") : "Rp".number_format(4500000 * $item->luas_bangunan, 0, ",", ".") ?></span></p>
                                      	<div class="product-statistic">
                                            <div class="statistic">
                                                <button class="btn btn-detail" onclick="detailRumah(<?= $item->id_rumah ?>)">Detail</a>
                                            </div>
                                            <div class="statistic">
                                                <span class="view">
                                                  	<i class="fa fa-eye"></i><?= $item->dilihat ?>
                                              	</span>
                                            </div>
                                            <div class="statistic">
                                              	<span class="like">
                                                  <i class="fa fa-heart-o" data-id="<?= $item->id_rumah ?>"></i><span class="value"><?= $item->suka ?></span>
                                                </span>
                                            </div>
                                          	<div class="statistic">
                                                <div class="share"><i class="fa fa-share-alt"></i>
                                                  <div class="social">
                                                      <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                                                      <a class="twitter" href="https://twitter.com/intent/tweet?text=Hello%20twitter%20https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                                                      <a class="whatsapp" href="https://web.whatsapp.com/send?text=https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah.' '.$item->nama_rumah ?>" target="_blank"><i class="fa fa-whatsapp"></i></a>
                                                  </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
              <?php }} ?>
              </div>
          </div>
      </div>
  </div>
</section>

<section class="pb-4 mt-35">
  <div class="container p0">
      <div class="row">
          <div class="col-md-12">
              <center>
              	  <h3 style="font-weight: 400;font-size: 28px;">Desain Terbaru</h3>
  				  <div class="line-footer"></div>
              </center>
          </div>
          <div class="col-md-12">
              <div class="list-produk-popular">
              <?php
                  if ($produk_terbaru != '') {
                      foreach($produk_terbaru as $item) { ?>
                        <div class="col-md-3 p0 grid">
                            <div class="product-grid">
                                <div class="product-image desain">
                                    <a href="javascript:void(0)" class="image" onclick="detailRumah(<?= $item->id_rumah ?>)">
                                        <img class="pic-1" src="<?= base_url('assets/img/desain/'.$item->foto) ?>">
                                        <img class="pic-2" src="<?= base_url('assets/img/desain/'.$item->foto) ?>">
                                    </a>
                                </div>
                                <div class="product-content">
                                    <div class="title" title="<?= $item->nama_rumah ?>" onclick="detailRumah(<?= $item->id_rumah ?>)"><?= $item->nama_rumah ?></div>
                                    <div class="product-rating">
                                        <div class="arsitek" title="<?= $item->nama_arsitek ?>" onclick="detailArsitek(<?= $item->id_arsitek ?>)"><?= $item->nama_arsitek ?></div>
                                        <div class="jstars" data-value="<?= $item->rating ?>" data-color="gold" data-size="17px"></div>
                                    </div>
                                    <div class="product-feature">
                                        <div class="feature" data-tootik="Luas Lahan" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_luas_lahan.png') ?>" />
                                            <span><?= $item->luas_lahan ?> m<sup>2</sup></span>
                                        </div>
                                        <div class="feature" data-tootik="Luas Bangunan" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_luas_bangunan.png') ?>" />
                                            <span><?= $item->luas_bangunan ?> m<sup>2</sup></span>
                                        </div>
                                        <div class="feature" data-tootik="Lantai" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_jml_lantai.png') ?>" />
                                            <span><?= $item->lantai ?></span>
                                        </div>
                                        <div class="feature" data-tootik="Kamar Tidur" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_kmr_tidur.png') ?>" />
                                            <span><?= $item->kamar_tidur ?></span>
                                        </div>
                                        <div class="feature" data-tootik="Toilet" data-tootik-conf="square">
                                            <img src="<?= base_url('assets/img/icon/icon_toilet.png') ?>" />
                                            <span><?= $item->toilet ?></span>
                                        </div>
                                    </div>
                                    <div class="product-detail">
                                        <p class="lahan-minimal">Lahan minimal <span class="bold"><?= $item->lebar_lahan.' m x '.$item->panjang_lahan.' m' ?></span></p>
                                      	<p>Biaya konstruksi <span class="bold" data-tootik="Estimasi awal" data-tootik-conf="square"><?= $item->lantai == '1' ? "Rp".number_format(3500000 * $item->luas_bangunan, 0, ",", ".") : "Rp".number_format(4500000 * $item->luas_bangunan, 0, ",", ".") ?></span></p>
                                        <div class="product-statistic">
                                            <div class="statistic">
                                                <button class="btn btn-detail popular" onclick="detailRumah(<?= $item->id_rumah ?>)">Detail</a>
                                            </div>
                                            <div class="statistic">
                                                <span class="view">
                                                    <i class="fa fa-eye"></i><?= $item->dilihat ?>
                                                </span>
                                            </div>
                                            <div class="statistic">
                                                <span class="like">
                                                  <i class="fa fa-heart-o" data-id="<?= $item->id_rumah ?>"></i><span class="value"><?= $item->suka ?></span>
                                                </span>
                                            </div>
                                            <div class="statistic">
                                                <div class="share"><i class="fa fa-share-alt"></i>
                                                  <div class="social">
                                                      <a class="facebook" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                                                      <a class="twitter" href="https://twitter.com/intent/tweet?text=Hello%20twitter%20https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah ?>" target="_blank"><i class="fa fa-twitter"></i></a>
                                                      <a class="whatsapp" href="https://web.whatsapp.com/send?text=https%3A%2F%2Festimator.id%2Farsi-hack%2Fdetail%2F<?= $item->id_rumah.' '.$item->nama_rumah ?>" target="_blank"><i class="fa fa-whatsapp"></i></a>
                                                  </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
              <?php }} ?>
              </div>
          </div>
      </div>
  </div>
</section>

<section class="pb-4" style="margin-top: 45px;">
	<div class="container p0">
      <div class="row">
          <div class="col-md-12 pb-25">
              <center>
                  <h3 style="font-weight: 400;font-size: 28px;">Katalog Material</h3>
                  <div class="line-footer mb-10"></div>
                  <h5 style="font-weight: 300;">Temukan material terbaik untuk rumah tinggal idaman Anda</h5>
              </center>
          </div>
          <div class="col-md-12">
              <div class="container p0 katalog-produk" style="width: 100%;">
                  <div class="row mb-4">
                  	  <div class="col-md-12" style="display: flex;justify-content: center;">
                          <form id="frm-filter" style="width: 45%;">
                              <input type="hidden" id="merk" name="merk">
                              <input type="hidden" id="id_kategori" name="id_kategori">
                              <input type="hidden" id="sort_by" name="sort_by" value="1">
                              <div class="p-1 bg-light rounded-pill shadow-sm">
                                  <div class="input-group">
                                    <input type="search" placeholder="Material apa yang Anda inginkan?" aria-describedby="btn-cari-material" class="form-control border-0 bg-light" id="nama_material" name="nama_produk" style="margin-left: 3px;">
                                    <div class="input-group-append">
                                      <button id="btn-cari-material" type="button" class="btn btn-link"><i class="fa fa-search"></i></button>
                                    </div>
                                  </div>
                              </div>
                          </form>
                      </div>
                  </div>
                  <div class="row mb-3">
                      <div class="col-md-12">
                          <div class="list-produk-merk">
                              <?php
                                if ($slide_merk != '') {
                                  foreach($slide_merk as $item) { ?>
                                      <div class="slide-brand" style="background: url(<?= $this->config->item('eid').'assets/img/merk/'.$item->logo ?>);background-size: 100% 100%;"></div>
                              <?php }} ?>
                          </div>
                      </div>
                  </div>
                  <div class="row">
                      <div class="col-md-12">
                          <div class="result">
                              <div class="row">
                                  <div class="col-md-3 sec-category" style="max-width: 21%;padding-right: 0;">
                                      <h5 style="font-weight: 400"><i class="fa fa-filter"></i> Tampilkan Berdasarkan</h5>
                                      <hr style="margin-top: 12px;">
                                      <div class="list-category">
                                        <div class="header">
                                          <h5>Kategori Material</h5>
                                        </div>
                                        <div class="body">
                                          <ul>
                                            <li data-id="0"><img class="icon" src="<?= $this->config->item('eid').'assets/img/icon/kategori/semua-kategori.png' ?>" />Semua Kategori</li>
                                            <?php
                                              if ($kategori != '') {
                                                foreach($kategori as $item){ ?>
                                                    <li data-id="<?= $item->id_kategori ?>"><img class="icon" src="<?= $this->config->item('eid').'assets/img/icon/kategori/'.$item->icon ?>" /><?= $item->kategori ?>
                                                        <?php if ($item->jumlah != '0') { ?>
                                                        <span class="pull-right"><span class="badge" style="vertical-align: sub;"><?= $item->jumlah ?></span></span>
                                                        <?php } ?>
                                                    </li>
                                            <?php }} ?>
                                          </ul>
                                        </div>
                                      </div>
                                      
                                      <div class="list-category merk">
                                          <div class="header">
                                            <h5>Merk Material</h5>
                                          </div>
                                          <ul class="list-group checklist"></ul>
                                      </div>
                                  </div>

                                  <div class="col-md-9 sec-product" style="max-width: 79%;flex: 0 0 79%;">
                                    <div class="row">
                                      <div class="col-md-6">
                                        <h5 style="font-weight: 300;font-size:15px;">Menampilkan <span id="jum_produk" style="font-weight: 400;"></span> material</h5>
                                      </div>
                                      
                                      <div class="col-sm-6 text-right">
                                        <div class="btn-group">
                                          <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" style="padding: 2px 10px;font-weight: 300;font-size: 15px;margin-top: -6px;">
                                            Urutkan <span class="caret"></span>
                                          </button>
                                          <ul class="dropdown-menu" role="menu">
                                              <li onclick="setSort(1)">Produk Terbaru</li>
                                              <li onclick="setSort(2)">Produk Terlama</li>
                                              <li onclick="setSort(3)">Harga Termurah</li>
                                              <li onclick="setSort(4)">Harga Termahal</li>
                                              <li onclick="setSort(5)">Abjad A-Z</li>
                                              <li onclick="setSort(6)">Abjad Z-A</li>
                                          </ul>
                                        </div>
                                      </div>
                                    </div>
                                    <hr style="margin-top: 7px;">
                                    
                                    <div class="list-produk"></div>
                                    <div class="spinner"><center><img src="<?= base_url('assets/gif/rt-loader.gif') ?>" style="padding: 2px;" width="35px" /></center></div>
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
	</div>
</section>

<section class="pb-4 mt-20">
  <div class="container p0">
      <div class="row">
          <div class="col-md-12">
              <center>
              	  <h3 style="font-weight: 400;font-size: 28px;">Artikel Desain</h3>
  				  <div class="line-footer" style="margin-bottom: 16px;"></div>
              </center>
          </div>
        
          <div class="col-md-12">
              <div class="list-artikel">
              <?php
                  if ($artikel != '') {
                      foreach($artikel as $item) {
                        $isi = substr($item->isi_artikel,0,200);
                        switch (date("m", strtotime($item->tgl_dibuat))) {
                          case 1: $bulan = 'Januari'; break;
                          case 2: $bulan = 'Februari'; break;
                          case 3: $bulan = 'Maret'; break;
                          case 4: $bulan = 'April'; break;
                          case 5: $bulan = 'Mei'; break;
                          case 6: $bulan = 'Juni'; break;
                          case 7: $bulan = 'Juli'; break;
                          case 8: $bulan = 'Agustus'; break;
                          case 9: $bulan = 'September'; break;
                          case 10: $bulan = 'Oktober'; break;
                          case 11: $bulan = 'November'; break;
                          case 12: $bulan = 'Desember'; break;
                        }
                        $publish = date("d", strtotime($item->tgl_dibuat)).' '.$bulan.' '.date("Y", strtotime($item->tgl_dibuat));
               		  ?>
                        <div class="col-md-3 p0 grid artikel-mobile">
                            <div class="product-grid">
                                <div class="product-image">
                                    <a href="javascript:void(0)" class="image" onclick="detailArtikel(<?= $item->id_artikel ?>)">
                                        <img class="pic-1" src="<?= base_url('assets/img/artikel/'.$item->foto_cover) ?>">
                                        <img class="pic-2" src="<?= base_url('assets/img/artikel/'.$item->foto_cover) ?>">
                                    </a>
                                </div>
                                <div class="product-content">
                                  	<div class="publish"><?= $publish ?></div>
                                    <div class="title" title="<?= $item->judul_artikel ?>" onclick="detailArtikel(<?= $item->id_artikel ?>)"><?= $item->judul_artikel ?></div>
                                  	<div class="content"><?= $isi ?></div>
                                  	<a href="<?= base_url('detail-artikel/'.$item->id_artikel) ?>" class="link">Selengkapnya</a>
                                </div>
                            </div>
                        </div>
              <?php }
                    foreach($artikel as $item) {
                        $isi = substr($item->isi_artikel,0,200);
                        switch (date("m", strtotime($item->tgl_dibuat))) {
                          case 1: $bulan = 'Januari'; break;
                          case 2: $bulan = 'Februari'; break;
                          case 3: $bulan = 'Maret'; break;
                          case 4: $bulan = 'April'; break;
                          case 5: $bulan = 'Mei'; break;
                          case 6: $bulan = 'Juni'; break;
                          case 7: $bulan = 'Juli'; break;
                          case 8: $bulan = 'Agustus'; break;
                          case 9: $bulan = 'September'; break;
                          case 10: $bulan = 'Oktober'; break;
                          case 11: $bulan = 'November'; break;
                          case 12: $bulan = 'Desember'; break;
                        }
                        $publish = date("d", strtotime($item->tgl_dibuat)).' '.$bulan.' '.date("Y", strtotime($item->tgl_dibuat));
               		  ?>
                        <div class="col-md-3 col-sm-6 p0 grid artikel-mobile">
                            <div class="product-grid">
                                <div class="product-image">
                                    <a href="javascript:void(0)" class="image" onclick="detailArtikel(<?= $item->id_artikel ?>)">
                                        <img class="pic-1" src="<?= base_url('assets/img/artikel/'.$item->foto_cover) ?>">
                                        <img class="pic-2" src="<?= base_url('assets/img/artikel/'.$item->foto_cover) ?>">
                                    </a>
                                </div>
                                <div class="product-content">
                                  	<div class="publish"><?= $publish ?></div>
                                    <div class="title" title="<?= $item->judul_artikel ?>" onclick="detailArtikel(<?= $item->id_artikel ?>)"><?= $item->judul_artikel ?></div>
                                  	<div class="content"><?= $isi ?></div>
                                  	<a href="<?= base_url('detail_artikel/'.$item->id_artikel) ?>" class="link">Selengkapnya</a>
                                </div>
                            </div>
                        </div>
              <?php }} ?>
              </div>
              <center><button class="btn btn-detail mt-2" onclick="lihatArtikel()" style="padding: 5px 9px;">Lihat Semua</button></center>
          </div>
      </div>
  </div>
</section>
<!--
<section class="pb-4 mt-20">
  <div class="container p0">
      <div class="row">
          <div class="col-md-12">
              <center>
              	  <h3 style="font-weight: 400;font-size: 28px;">Testimoni</h3>
  				  <div class="line-footer"></div>
              </center>
          </div>
        
          <div class="col-md-8" style="left: 17%;">
              <div id="testimonial-slider" class="owl-carousel owl-theme">
                  <div class="testimonial">
                      <p class="description">
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec velit dui. Pellentesque volutpat faucibus risus, ac accumsan purus.
                      </p>

                      <div class="review">
                          <div class="pic"><img src="https://image.ibb.co/cNP817/pexels_photo_220453.jpg"></div>
                          <h4 class="title">
                              Theo Rifai
                              <small>Arsitek</small>
                          </h4>
                      </div>
                  </div>
                  <div class="testimonial">
                      <p class="description">
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec velit dui. Pellentesque volutpat faucibus risus, ac accumsan purus.
                      </p>

                      <div class="review">
                          <div class="pic"><img src="https://image.ibb.co/iN3qES/pexels_photo_324658.jpg"></div>
                          <h4 class="title">
                              Riani ZAP
                              <small>Sipil</small>
                          </h4>
                      </div>
                  </div>
                  <div class="testimonial">
                      <p class="description">
                          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut nec velit dui. Pellentesque volutpat faucibus risus, ac accumsan purus.
                      </p>

                      <div class="review">
                          <div class="pic"><img src="https://image.ibb.co/cNP817/pexels_photo_220453.jpg"></div>
                          <h4 class="title">
                              Yogi S
                              <small>Drafter</small>
                          </h4>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section>
-->

<!-- <div class="modal fade" id="pop_up_website">
  <div class="modal-dialog animated tada">
    <div class="">
      <div class="">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <!- <h4 class="modal-title">Modal title</h4> ->
      </div>
      <div class="text-center">
        <img src="<?php echo base_url('assets/img/pop_up/pop_up_website.png') ?>" width="500px;">
        <button class="btn btn-danger" onclick="lihatKoleksi()" style="padding: 5px 11px;margin-top: -202px;font-size: 17px;border-radius: 25px;background: red;border-color: red;">Dapatkan Sekarang</button>
      </div>
    </div>
  </div>
</div> -->

<div id="pop_up_website" data-backdrop="static" data-keyboard="false" class="modal fade center-screen in" role="dialog" style="background-color: rgba(0, 0, 0, 0.3); padding-right: 17px;" aria-hidden="false">
  <div class="modal-dialog animated tada" style="z-index: 2;width: 555px;">
    <div class="modal-content" style="background: transparent;box-shadow: none;border: none;">
      <div class="modal-body" style="text-align: center;">
        <a class="close" data-dismiss="modal" style="position: absolute;right: 40px;top: 30px;">×</a>
          <img src="<?php echo base_url('assets/img/pop_up/pop_up_website.png') ?>" width="500px;" class="pop-up-website">
        <button class="btn btn-danger btn-pop-up btn-konsultasi" onclick="lihatKoleksi()" style="padding: 5px 11px;margin-top: -205px;font-size: 21px;border-radius: 25px;background: red;border-color: red;box-shadow: 0px 3px 5px 5px rgba(38, 38, 38, 0.19),0px 2px 2px 1px rgba(184, 184, 184, 0.45);">Dapatkan Sekarang</button>
      </div>
    </div>
  </div>
</div>





<script src="<?php echo base_url('assets/js/js.cookie.min.js') ?>"></script>
<script src="https://accounts.google.com/gsi/client" async defer></script>

<script>
    function parseJwt(token) {
          var base64Url = token.split('.')[1];
          var base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
          var jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
              return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
          }).join(''));

          return JSON.parse(jsonPayload);
    };

    function handleCredentialResponse(credentialResponse) {
        let response = parseJwt(credentialResponse.credential);
        $.ajax({
            url : "<?php echo base_url('api/loginSSO') ?>",
            type: "POST",
            data: {
                "nama_lengkap": response.name,
                "email": response.email,
                "password": ''
            },
            dataType: "JSON",
            success: function(data){
                if (data.Success == true) {
                    toastr.success(data.Info, 'Informasi', opsi_toastr);
                    window.location.href = "<?php echo base_url() ?>";
                }
            }
        });
    }

    if (Cookies.get('id_customer', { domain: 'rumahtinggal.id' }) == null) {
        window.onload = function () {
            google.accounts.id.initialize({
                client_id: '234359626392-2anp0ui8kep8kp2v2ec54k7cdbdf7a1g.apps.googleusercontent.com',
                callback: handleCredentialResponse,
                cancel_on_tap_outside: false,
                //ui_mode: isMobile() ? 'bottom_sheet': 'card',
            });
            google.accounts.id.prompt();

            setTimeout(function(){
                let onetap = $('.wrapper > #credential_picker_container');
                onetap.parent().after(onetap);
            }, 7000);
        };
    }

    $(document).ready(function() {
        ias.bind();
      	getSummaryKatalog();
        getMerkProduk();
        $('#pop_up_website').modal('show');
        $('#testimonial-slider').owlCarousel({
            items: 1,
          	loop: true,
            //margin: 10,
          	autoplay: true,
          	autoplayHoverPause: true,
          	autoplaySpeed: 2000
        });
      
      	$('.list-produk-merk').slick({
          	autoplaySpeed: 2000,
          	autoplay: true,
            slidesToShow: 7,
            slidesToScroll: 1,
          	arrows: false,
          	dots: true,
            responsive: [
              {
                breakpoint: 1024,
                settings: {
                  slidesToShow: 3,
                  slidesToScroll: 1,
                  infinite: true,
                  dots: true
                }
              },
              {
                breakpoint: 600,
                settings: {
                  slidesToShow: 2,
                  slidesToScroll: 1
                }
              },
              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1
                }
              }
            ]
        });
      
      	$('.list-produk-promo, .list-produk-favorit, .list-artikel').slick({
             slidesToShow: 4,
             slidesToScroll: 1,
             autoplay: true,
             autoplaySpeed: 2000,
             arrows: true,
             responsive: [{
                     breakpoint: 1024,
                     settings: {
                         slidesToShow: 3,
                         slidesToScroll: 1,
                         infinite: true,
                         dots: true
                     }
                 },
                 {
                     breakpoint: 600,
                     settings: {
                         slidesToShow: 2,
                         slidesToScroll: 1
                     }
                 },
                 {
                     breakpoint: 480,
                     settings: {
                         slidesToShow: 2,
                         slidesToScroll: 1,
                         arrows: false
                     }
                 }
             ]
        });
    });
  
    function lihatKoleksi(){
      	location.href = "<?= base_url('desain') ?>";
    }
  
  	function lihatSampel(){
      	location.href = "<?= base_url('sampel_desain') ?>";
    }
  
  	function detailProduk(id){
        location.href = "<?= base_url('detail_produk/') ?>"+id;
    }
  
  	function lihatArtikel(){
      	location.href = "<?= base_url('artikel') ?>";
    }
  
  	function detailArtikel(id){
      	location.href = "<?= base_url('detail-artikel/') ?>"+id;
    }
    
    function detailSuplier(id){
        //location.href = "<?= base_url('suplier/') ?>"+id;
    }
    
    function detailMerk(id){
        //location.href = "<?= base_url('merk/') ?>"+id;
    }
    
    function setSort(by) {
        $('#sort_by').val(by);
        $('.list-produk').empty();
        ias.next();
    }
  
  	function getProductItem(page,data) {
        var foto = `${data.foto}`;
        if (foto == '') foto = 'no-foto.jpg';
        var harga = `${data.harga_dasar}`;
        
        var template = `<div class="col-md-3 col-sm-6 p0 grid">
            <div class="product-grid page-`+page+`" data-id="${data.id_produk}">
                <div class="product-image">
                    <a href="javascript:void(0)" class="image" onclick="detailProduk(${data.id_produk})">
                        <img class="pic-1" src="<?= $this->config->item('eid').'assets/foto/produk/' ?>`+foto+`">
                        <img class="pic-2" src="<?= $this->config->item('eid').'assets/foto/produk/' ?>`+foto+`">
                    </a>
                </div>
                <div class="product-content">
                    <div class="title" title="${data.nama_produk}" onclick="detailProduk(${data.id_produk})">${data.nama_produk}</div>
					<div class="product-info">
                        <div class="suplier" title="${data.nama_suplier}" onclick="detailSuplier(${data.id_suplier})">
							<img class="logo" src="<?= $this->config->item('eid').'assets/foto/pengguna/' ?>${data.foto_suplier}">
							<span>${data.nama_suplier}</span>
  						</div>
                        <div class="badge" title="${data.merk}">${data.merk}</div>
                    </div>
					<div class="product-price">
						<div class="price">Rp`+number_format(harga, 0, ',', '.')+`<span class="unit"> / ${data.satuan}</span></div>
					</div>
                    <div class="product-detail">
                        <p class="spesification">${data.spesifikasi}</p>
                        <div class="product-statistic">
                            <div class="statistic">
                                <button class="btn btn-detail produk" onclick="detailProduk(${data.id_produk})">Detail</a>
                            </div>
                            <div class="statistic">
                                <button class="btn btn-beli" data-number="${data.no_wa}" data-id="${data.id_produk}" data-product="${data.nama_produk}" data-merk="${data.merk}" data-spec="${data.spesifikasi}"><i class="fa fa-shopping-cart" style="margin-top: -1px;"></i> Beli</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>`;

        let item = document.createElement('div');
        item.innerHTML = template.trim();

        return item.firstChild;
    }

    var params = null, page = 0;
    function nextHandler(pageIndex) {
        if (params == null) params = $('#frm-filter').serialize();
        else {
            if (params != $('#frm-filter').serialize()) {
                params = $('#frm-filter').serialize();
                page = reset = 0;
            } else page++;
        }

        let fetchData = {
            method: 'POST',
            body: params,
            headers: new Headers()
        }

        return fetch('<?= $this->config->item('url_server') ?>api/getKatalogProduk', fetchData)
            .then(response => response.json())
            .then(result => {
              let frag = document.createDocumentFragment();
              let itemsPerPage = 10;
              let totalPages = Math.ceil(result.length / itemsPerPage);
              let offset = page * itemsPerPage;

              for (let i = offset, len = offset + itemsPerPage; i < len; i++) {
                if (typeof result[i] !== 'undefined') {
                    let item = getProductItem(pageIndex, result[i]);
                    frag.appendChild(item);
                }
              }

              let hasNextPage = page < totalPages - 1;

              return this.append(Array.from(frag.childNodes)).then(() => hasNextPage);
            })
            .catch(error => console.log(error));
    }

    window.ias = new InfiniteAjaxScroll('.list-produk', {
        logger: false,
        item: '.grid',
        next: nextHandler,
        pagination: false,
        bind: false,
        scrollContainer: '.list-produk',
        spinner: '.spinner',
    });

    ias.on('page', (event) => {
        $(".btn-beli").on("click", function(){
            var id_produk = $(this).attr("data-id");
            var nama_produk = $(this).attr("data-product");
            var merk = $(this).attr("data-merk");
            var spesifikasi = $(this).attr("data-spec").replace(/<[^>]*>/g," ");
            var text = `Halo,\nSaya ingin membeli produk Anda dengan rincian:\n\nNama Produk: `+nama_produk+`\nMerk: `+merk+`\nSpesifikasi: `+spesifikasi+`\nLink Produk: <?php echo base_url('detail/') ?>`+id_produk+`\n\nApakah bisa dibantu?\nTerima kasih`;
            var phone = $(this).attr("data-number");
            var message = encodeURIComponent(text);

            if (phone.substring(0,1) == '+') phone = phone.substring(1);
            else if (phone.substring(0,1) == '0') {
                phone = phone.substring(1);
                phone = '62'+phone;
            }
            
            if (isMobile() == true){
                //mobile device
                var whatsapp_API_url = "whatsapp://send";
                $(this).attr( 'href', whatsapp_API_url+'?phone=' + phone + '&text=' + message );
            } else {
                //desktop
                var whatsapp_API_url = "https://web.whatsapp.com/send";
                var url = whatsapp_API_url+'?phone=' + phone + '&text=' + message; 
                window.open(url, '_blank');
            }
        });
    });
    
    function getSummaryKatalog() {
        $.ajax({
            type : 'POST',
            url : "<?= $this->config->item('url_server') ?>api/getSummaryCariProduk",
            dataType: "JSON",
            data: {
                "keyword": $('#nama_material').val(),
                "id_kategori": $('#id_kategori').val(),
                "merk": $('#merk').val()
            },
            success : function(data){
                $('#jum_produk').html(data.suplier);
            },
            error: function (jqXHR, textStatus, errorThrown){
              toastr.error('Terjadi masalah saat pengambilan data.', 'Kesalahan', opsi_toastr);
            }
        });
    }
    
    function getMerkProduk() {
        $.ajax({
            type : 'POST',
            url : "<?= $this->config->item('url_server') ?>api/getFilterMerkProduk",
            data: $('#frm-filter').serialize(),
            dataType: "JSON",
            success : function(data){
                if (data != '') {
                    var list = check = counter = '';
                    var list_merk = $('#merk').val();
                    for (var i = 0; i <= data.length-1; i++) {
                        if (list_merk.includes(data[i].merk) == true) check = "checked"; else check = "";
                        if (data[i].jumlah != "0") counter = "<span class='pull-right'><span class='badge' style='vertical-align: middle;'>"+data[i].jumlah+"</span></span>"; else counter = "";
                        list += '<li class="list-group-item"><label class="checkbox"><input type="checkbox" class="list-merk" name="list_merk" value="'+data[i].merk+'" '+check+'><span class="primary"><div class="item">'+data[i].merk+'</div></label>'+counter+'</li>';
                    }
                    $('.checklist').html(list);
                } else $('.checklist').html("<center><img src='<?= $this->config->item('eid') ?>assets/img/not-found.png' width='75' style='padding: 5px 0px;' /><br><span>Tidak ada merk material</span></center>");
                
              	$(".list-merk").on("change", function(e) {
                    var merk = '';
                    $.each($(".checklist :input").serializeArray(), function() {
                        merk += "'" + this.value + "',";
                    });
                    $('#merk').val(merk.slice(0,-1));
                  	$('.list-produk').empty();
                    ias.next();
                    getSummaryKatalog();
                });
            },
            error: function (jqXHR, textStatus, errorThrown){
              toastr.error('Terjadi masalah saat pengambilan data.', 'Kesalahan', opsi_toastr);
            }
        });
    }
  
  	$('#nama_material').keypress(function(e){
    	if (e.which == 13) {
          e.preventDefault();
          $('#btn-cari-material').click();
          return false;
        }
  	})
  
  	$('#btn-cari-material').on('click', function() {
        $('#id_kategori').val(0);
      	$('#merk').val('');
        $('.list-produk').empty();
        ias.next();
      	getSummaryKatalog();
        getMerkProduk();
    });  
  
  	$('.list-category .body li').on('click', function() {
        $('#id_kategori').val($(this).data('id'));
        $('#nama_material,#merk').val('');
        $('.list-produk').empty();
        ias.next();
      	getSummaryKatalog();
        getMerkProduk();
    });






</script>